<?php
require __DIR__ . "/models/history.php"
?>

<!DOCTYPE html>
<html lang="fr">
    <head>
    <?php include 'includes/head.php'; ?>
        <title>Online shifumi - Historique des parties</title>
    </head>
    <body>
        <?php include 'includes/nav.php'; ?>
        <main>
        <h1>Historique des parties</h1>
<table>
    <thead>
        <tr>
            <th>Date</th>
            <th>Main jouée</th>
            <th>Main CPU</th>
            <th>Résultat</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $history = getHistory();

            foreach ($history as $match) {
                echo '<tr>';
                echo '<td>' . htmlspecialchars($match['date']) . '</td>';
                echo '<td>' . htmlspecialchars($match['handPlayedByUser']) . '</td>';
                echo '<td>' . htmlspecialchars($match['handPlayedByCPU']) . '</td>';
                echo '<td>' . htmlspecialchars($match['result']) . '</td>';
                echo '</tr>';
            }
            ?>
    </tbody>
    </table>
                    
                
        </main>
        <?php include 'includes/footer.php'; ?>
    </body>
</html>
