<!DOCTYPE html>
<html lang="fr">
    <head>
        <?php include 'includes/head.php'; ?>
        <title>Online shifumi - Accueil</title>
    </head>
    <body>
        <?php include 'includes/nav.php'; ?>
        <main>
            <h1>Shifumi en ligne</h1>

        </main>
        <?php include 'includes/footer.php'; ?>
    </body>
</html>
