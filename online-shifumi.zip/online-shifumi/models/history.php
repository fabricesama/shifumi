<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . "/../mysql/connection.php";

function saveMatchHistory(string $userHand, string $cpuHand, string $gameState) {
    $pdo = connection();

    $date = date('Y-m-d H:i:s');

    $sql = "INSERT INTO games (date, handPlayedByUser, handPlayedByCPU, result)
            VALUES ('$date', '$userHand', '$cpuHand', '$gameState')";

    $pdo->exec($sql);
}

function getHistory() {
    $pdo = connection();
    
    try {
        $stmt = $pdo->query("SELECT date, handPlayedByUser, handPlayedByCPU, result FROM games ORDER BY date DESC");
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $data;
    } catch (PDOException $e) {
        return [];
    }
}