<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/history.php';

if (empty($_POST)) {
    header('Location: ../game.php');
    exit;
}

session_start();

function getHandTypes(): array {
    return [
        'rock',
        'paper',
        'scissors'
    ];
}

function getCpuHand(): string {
    $randomIndex = rand(0,2);
    return getHandTypes()[$randomIndex];
}

function getHandAdvantage(): array {
    return [
        'rock' => 'scissors',
        'paper' => 'rock',
        'scissors' => 'paper'
    ];
}

function getMatchResult(string $userHand, string $cpuHand): string {
    if($userHand === $cpuHand) {
        return 'DRAW';
    }

    if($cpuHand === getHandAdvantage()[$userHand]) {
        return 'WON';
    }

    return 'LOST';
}


$cpuHand = getCpuHand();

$matchResult = getMatchResult($_POST['userHand'], $cpuHand);

// Traductions
$userHand = ['rock' => 'pierre','paper' => 'feuille','scissors' => 'ciseaux'][$_POST['userHand']];
$cpuHand = ['rock' => 'pierre','paper' => 'feuille','scissors' => 'ciseaux'][$cpuHand];
$matchResult = ['WON' => 'VICTOIRE','LOST' => 'DÉFAITE','DRAW' => 'NUL'][$matchResult];

saveMatchHistory($userHand, $cpuHand, $matchResult[0]);

header("Location: ../result.php?result=" . urlencode($matchResult) . "&userHand=" . urlencode($_POST['userHand']) . "&cpuHand=" . urlencode($cpuHand));

?>