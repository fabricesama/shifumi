<!DOCTYPE html>
<html lang="fr">
    <head>
        <?php include 'includes/head.php'; ?>
        <title>Online shifumi - Résultat</title>
    </head>
    <body>
        <?php include 'includes/nav.php'; ?>
        <main>
            <h1>Résultat de la partie</h1>
        </main>

        <body>
            <h1>
                <?php echo $_GET["result"] ?>
            </h1>
            <p>
            Tu as choisi : <?php echo $_GET["userHand"] ?> <br>
            Ton adversaire à choisi : <?php echo $_GET["cpuHand"] ?>
            </p>
        </body>

        <?php include 'includes/footer.php'; ?>
    </body>
</html>
