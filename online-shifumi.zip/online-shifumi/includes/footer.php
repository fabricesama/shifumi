<footer>
    <p>Online shifumi</p>
</footer>