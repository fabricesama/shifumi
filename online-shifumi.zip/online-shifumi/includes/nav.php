<nav>
    <ul>
        <li>
            <a href="./">Accueil</a>
        </li>
        <li>
            <a href="./game.php">Nouvelle partie</a>
        </li>
        <li>
            <a href="./history.php">Historique des parties</a>
        </li>
    </ul>
</nav>