<?php
function connection() {
    $pdo = new PDO('mysql:host=localhost;dbname=shifumi;charset=utf8', 'root', '');
    return $pdo;
}
?>